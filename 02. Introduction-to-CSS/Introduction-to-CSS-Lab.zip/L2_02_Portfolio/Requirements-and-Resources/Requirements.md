# 02 - Portfolio
------
Problems for in-class lab for the [“Web Fundamentals - HTML 5”](https://softuni.bg/trainings/2265/web-fundamentals-html5-january-2019/) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS)

## Constraints
* Change the title
* Divide your content into **header** and **main** tags
* Use **nav**, **ul**, **li** and **a** tags to create the navigation
* Use **section** tag to create two **sections** in the main
* Use **article** tag to create two **articles** in the second section
* Use **h2** tag for headings
* Use **img** tag for the image
* Use **Font Awesome** for the icons



