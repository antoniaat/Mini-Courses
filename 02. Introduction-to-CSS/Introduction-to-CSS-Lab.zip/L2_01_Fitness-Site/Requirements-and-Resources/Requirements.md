# 01 - Fitness Site
------
Problems for in-class lab for the [“Web Fundamentals - HTML 5”](https://softuni.bg/trainings/2265/web-fundamentals-html5-january-2019/) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS)

## Constraints
* Change the title
* Divide your content into **header**, **main** and **footer** tags
* Use **nav**, **ul**, **li** and **a** tags to create the navigation
* Use **article** tag to create three **articles** in the main
* Use **h3** tag for headings
* Use **Font Awesome** for the icons



