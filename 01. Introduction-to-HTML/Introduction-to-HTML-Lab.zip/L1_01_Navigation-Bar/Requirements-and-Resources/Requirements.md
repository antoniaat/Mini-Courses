# 01 - Navigation Bar
------
Problems for the [“HTML and CSS”](#) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS)

## Constraints
* Change the title
* Use **nav** tag to create a navigation
    * Use **ul** tag to create an unordered list
    * Use **li** tags for list items and add and hyperlinks with **a** tag inside them