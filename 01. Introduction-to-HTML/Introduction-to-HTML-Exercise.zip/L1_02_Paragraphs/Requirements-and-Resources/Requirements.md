# 02 - Paragraphs
------
Problems for homework for the [“HTML and CSS Basics”](#) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS)

## Constraints
* Change the document **title**
* Use **h1** tag for the title
* Use **p** tag to create the paragraphs
* See the provided screenshot and use **strong** and em **tags** where needed



