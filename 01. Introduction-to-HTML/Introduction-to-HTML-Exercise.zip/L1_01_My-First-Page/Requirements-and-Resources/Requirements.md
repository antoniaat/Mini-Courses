# 01 - My First Page
------
Problems for homework for the [“HTML and CSS Basics”](#) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS)

## Constraints
* Change the document **title** to "*My First Page*"
* Use **h1** tag for the title
* Add two paragraphs with text inside



