# 05 - Table
------
Problems for homework for the [“HTML and CSS Basics”](#) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS)

## Constraints
* Change the document **title**
* Use **h2** tag for the title
* Use **table**, **thead**, **tbody** and **tfoot** tags to create the **table**

## Hints
* You can add the **style.css** file from resources for better looking table